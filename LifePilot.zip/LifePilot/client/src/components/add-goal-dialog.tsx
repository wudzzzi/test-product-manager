import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Target } from "lucide-react";

export default function AddGoalDialog() {
  const [open, setOpen] = useState(false);
  const [goal, setGoal] = useState({
    title: "",
    description: "",
    targetValue: "",
    currentValue: "",
    unit: ""
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const addGoalMutation = useMutation({
    mutationFn: (newGoal: any) => apiRequest("POST", "/api/goals", newGoal),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/goals"] });
      toast({
        title: "Ціль додано!",
        description: "Нова ціль була успішно створена."
      });
      setGoal({ title: "", description: "", targetValue: "", currentValue: "", unit: "" });
      setOpen(false);
    },
    onError: () => {
      toast({
        title: "Помилка",
        description: "Не вдалося додати ціль.",
        variant: "destructive"
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!goal.title || !goal.targetValue) {
      toast({
        title: "Помилка валідації",
        description: "Назва цілі та цільове значення є обов'язковими.",
        variant: "destructive"
      });
      return;
    }

    const newGoal = {
      title: goal.title,
      description: goal.description || null,
      targetValue: parseInt(goal.targetValue) || 0,
      currentValue: parseInt(goal.currentValue) || 0,
      unit: goal.unit || null,
      completed: false
    };

    addGoalMutation.mutate(newGoal);
  };

  const units = [
    "кг",
    "л",
    "днів",
    "разів",
    "хвилин", 
    "км",
    "₴",
    "балів",
    "%",
    "шт"
  ];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="ghost"
          className="w-full text-primary hover:text-primary/80 text-sm font-medium"
          data-testid="button-set-new-goal"
        >
          <Target className="mr-2" size={16} />
          Додати нову ціль
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]" data-testid="dialog-add-goal">
        <DialogHeader>
          <DialogTitle>Додати нову ціль</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Назва цілі *</Label>
            <Input
              id="title"
              value={goal.title}
              onChange={(e) => setGoal({ ...goal, title: e.target.value })}
              placeholder="Наприклад: Схуднення"
              data-testid="input-goal-title"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Опис цілі</Label>
            <Textarea
              id="description"
              value={goal.description}
              onChange={(e) => setGoal({ ...goal, description: e.target.value })}
              placeholder="Детальний опис вашої цілі..."
              data-testid="input-goal-description"
              rows={3}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="current">Поточне значення</Label>
              <Input
                id="current"
                type="number"
                value={goal.currentValue}
                onChange={(e) => setGoal({ ...goal, currentValue: e.target.value })}
                placeholder="0"
                data-testid="input-goal-current"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="target">Цільове значення *</Label>
              <Input
                id="target"
                type="number"
                value={goal.targetValue}
                onChange={(e) => setGoal({ ...goal, targetValue: e.target.value })}
                placeholder="10"
                data-testid="input-goal-target"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="unit">Одиниця вимірювання</Label>
            <Select value={goal.unit} onValueChange={(value) => setGoal({ ...goal, unit: value })}>
              <SelectTrigger data-testid="select-goal-unit">
                <SelectValue placeholder="Оберіть одиницю" />
              </SelectTrigger>
              <SelectContent>
                {units.map(unit => (
                  <SelectItem key={unit} value={unit}>{unit}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex justify-end space-x-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              data-testid="button-cancel-add-goal"
            >
              Скасувати
            </Button>
            <Button
              type="submit"
              disabled={addGoalMutation.isPending}
              data-testid="button-save-add-goal"
            >
              {addGoalMutation.isPending ? "Додавання..." : "Додати ціль"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}