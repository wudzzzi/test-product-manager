import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Plus } from "lucide-react";

export default function AddScheduleItemDialog() {
  const [open, setOpen] = useState(false);
  const [item, setItem] = useState({
    title: "",
    description: "",
    startTime: "",
    duration: "",
    type: "",
    date: new Date().toISOString().split('T')[0]
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const addItemMutation = useMutation({
    mutationFn: (newItem: any) => apiRequest("POST", "/api/schedule", newItem),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/schedule"] });
      toast({
        title: "Завдання додано!",
        description: "Нове завдання було додано до розкладу."
      });
      setItem({ title: "", description: "", startTime: "", duration: "", type: "", date: new Date().toISOString().split('T')[0] });
      setOpen(false);
    },
    onError: () => {
      toast({
        title: "Помилка",
        description: "Не вдалося додати завдання.",
        variant: "destructive"
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!item.title || !item.startTime || !item.date) {
      toast({
        title: "Помилка валідації",
        description: "Назва, час початку та дата є обов'язковими полями.",
        variant: "destructive"
      });
      return;
    }

    const newItem = {
      title: item.title,
      description: item.description || null,
      startTime: item.startTime,
      duration: parseInt(item.duration) || null,
      type: item.type || null,
      date: item.date,
      completed: false
    };

    addItemMutation.mutate(newItem);
  };

  const types = [
    "workout", // тренування
    "meal", // прийом їжі
    "shopping", // покупки
    "work", // робота
    "personal", // особисте
    "health", // здоров'я
    "education", // навчання
    "entertainment" // розваги
  ];

  const typeLabels: { [key: string]: string } = {
    "workout": "Тренування",
    "meal": "Прийом їжі", 
    "shopping": "Покупки",
    "work": "Робота",
    "personal": "Особисте",
    "health": "Здоров'я",
    "education": "Навчання",
    "entertainment": "Розваги"
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="ghost"
          className="w-full text-primary hover:text-primary/80 text-sm font-medium"
          data-testid="button-add-to-schedule"
        >
          <Plus className="mr-2" size={16} />
          Додати до розкладу
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]" data-testid="dialog-add-schedule">
        <DialogHeader>
          <DialogTitle>Додати завдання до розкладу</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Назва завдання *</Label>
            <Input
              id="title"
              value={item.title}
              onChange={(e) => setItem({ ...item, title: e.target.value })}
              placeholder="Наприклад: Тренування у спортзалі"
              data-testid="input-schedule-title"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Опис</Label>
            <Textarea
              id="description"
              value={item.description}
              onChange={(e) => setItem({ ...item, description: e.target.value })}
              placeholder="Детальний опис завдання..."
              data-testid="input-schedule-description"
              rows={2}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="date">Дата *</Label>
              <Input
                id="date"
                type="date"
                value={item.date}
                onChange={(e) => setItem({ ...item, date: e.target.value })}
                data-testid="input-schedule-date"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="time">Час початку *</Label>
              <Input
                id="time"
                type="time"
                value={item.startTime}
                onChange={(e) => setItem({ ...item, startTime: e.target.value })}
                data-testid="input-schedule-time"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="duration">Тривалість (хв)</Label>
              <Input
                id="duration"
                type="number"
                value={item.duration}
                onChange={(e) => setItem({ ...item, duration: e.target.value })}
                placeholder="60"
                data-testid="input-schedule-duration"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="type">Тип завдання</Label>
              <Select value={item.type} onValueChange={(value) => setItem({ ...item, type: value })}>
                <SelectTrigger data-testid="select-schedule-type">
                  <SelectValue placeholder="Оберіть тип" />
                </SelectTrigger>
                <SelectContent>
                  {types.map(type => (
                    <SelectItem key={type} value={type}>{typeLabels[type]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex justify-end space-x-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              data-testid="button-cancel-add-schedule"
            >
              Скасувати
            </Button>
            <Button
              type="submit"
              disabled={addItemMutation.isPending}
              data-testid="button-save-add-schedule"
            >
              {addItemMutation.isPending ? "Додавання..." : "Додати завдання"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}