import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Plus } from "lucide-react";

export default function AddShoppingItemDialog() {
  const [open, setOpen] = useState(false);
  const [item, setItem] = useState({
    name: "",
    quantity: "",
    estimatedPrice: "",
    store: "",
    category: ""
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const addItemMutation = useMutation({
    mutationFn: (newItem: any) => {
      // For now, we'll create a new shopping list with the item
      return apiRequest("POST", "/api/shopping-lists", {
        name: "Ручний список",
        budget: 1000,
        totalCost: parseInt(newItem.estimatedPrice) || 0,
        items: [newItem]
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/shopping-lists"] });
      toast({
        title: "Товар додано!",
        description: "Новий товар було додано до списку покупок."
      });
      setItem({ name: "", quantity: "", estimatedPrice: "", store: "", category: "" });
      setOpen(false);
    },
    onError: () => {
      toast({
        title: "Помилка",
        description: "Не вдалося додати товар.",
        variant: "destructive"
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!item.name || !item.quantity) {
      toast({
        title: "Помилка валідації",
        description: "Назва та кількість є обов'язковими полями.",
        variant: "destructive"
      });
      return;
    }

    const newItem = {
      name: item.name,
      quantity: item.quantity,
      estimatedPrice: parseInt(item.estimatedPrice) || 0,
      store: item.store || "Не вказано",
      category: item.category || "Різне"
    };

    addItemMutation.mutate(newItem);
  };

  const categories = [
    "Овочі і фрукти",
    "М'ясо і риба", 
    "Молочні продукти",
    "Хліб і випічка",
    "Крупи і макарони",
    "Консерви",
    "Напої",
    "Побутова хімія",
    "Різне"
  ];

  const stores = [
    "АТБ",
    "Сільпо", 
    "Новус",
    "Метро",
    "Фора",
    "Варус",
    "Інше"
  ];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button 
          className="w-full bg-primary text-primary-foreground hover:opacity-90 font-medium"
          data-testid="button-add-item"
        >
          <Plus className="mr-2" size={16} />
          Додати товар
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]" data-testid="dialog-add-item">
        <DialogHeader>
          <DialogTitle>Додати товар до списку покупок</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Назва товару *</Label>
            <Input
              id="name"
              value={item.name}
              onChange={(e) => setItem({ ...item, name: e.target.value })}
              placeholder="Наприклад: Молоко"
              data-testid="input-item-name"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="quantity">Кількість *</Label>
            <Input
              id="quantity"
              value={item.quantity}
              onChange={(e) => setItem({ ...item, quantity: e.target.value })}
              placeholder="Наприклад: 1 л"
              data-testid="input-item-quantity"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="price">Орієнтовна ціна (₴)</Label>
            <Input
              id="price"
              type="number"
              value={item.estimatedPrice}
              onChange={(e) => setItem({ ...item, estimatedPrice: e.target.value })}
              placeholder="50"
              data-testid="input-item-price"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="store">Магазин</Label>
            <Select value={item.store} onValueChange={(value) => setItem({ ...item, store: value })}>
              <SelectTrigger data-testid="select-item-store">
                <SelectValue placeholder="Оберіть магазин" />
              </SelectTrigger>
              <SelectContent>
                {stores.map(store => (
                  <SelectItem key={store} value={store}>{store}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="category">Категорія</Label>
            <Select value={item.category} onValueChange={(value) => setItem({ ...item, category: value })}>
              <SelectTrigger data-testid="select-item-category">
                <SelectValue placeholder="Оберіть категорію" />
              </SelectTrigger>
              <SelectContent>
                {categories.map(category => (
                  <SelectItem key={category} value={category}>{category}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex justify-end space-x-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              data-testid="button-cancel-add-item"
            >
              Скасувати
            </Button>
            <Button
              type="submit"
              disabled={addItemMutation.isPending}
              data-testid="button-save-add-item"
            >
              {addItemMutation.isPending ? "Додавання..." : "Додати товар"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}