import { TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import AddGoalDialog from "@/components/add-goal-dialog";

export default function GoalsProgress() {
  const { data: goals, isLoading } = useQuery<any[]>({
    queryKey: ["/api/goals"],
  });

  if (isLoading) {
    return (
      <Card className="rounded-xl border border-border shadow-sm">
        <CardContent className="p-6">
          <div className="space-y-4">
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  // Mock goals data if no goals exist
  const mockGoals = [
    {
      id: "1",
      title: "Схуднення",
      currentValue: 7,
      targetValue: 10,
      unit: "кг",
      description: "Залишилось 3 кг до мети"
    },
    {
      id: "2", 
      title: "Тренування в тиждень",
      currentValue: 4,
      targetValue: 5,
      unit: "днів",
      description: "Чудовий результат!"
    },
    {
      id: "3",
      title: "Вода в день",
      currentValue: 1.5,
      targetValue: 2,
      unit: "л",
      description: "Ще трошки!"
    }
  ];

  const displayGoals = goals?.length ? goals : mockGoals;

  const getProgressColor = (progress: number) => {
    if (progress >= 80) return "bg-secondary";
    if (progress >= 60) return "bg-primary";
    if (progress >= 40) return "bg-yellow-500";
    return "bg-blue-500";
  };

  return (
    <Card className="rounded-xl border border-border shadow-sm">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">Прогрес цілей</h3>
          <Button 
            variant="ghost" 
            size="icon"
            className="text-muted-foreground hover:text-foreground"
            data-testid="button-goals-chart"
          >
            <TrendingUp size={16} />
          </Button>
        </div>
        
        <div className="space-y-4" data-testid="goals-list">
          {displayGoals.map((goal: any, index: number) => {
            const progress = Math.round((goal.currentValue / goal.targetValue) * 100);
            const progressColor = getProgressColor(progress);
            
            return (
              <div key={goal.id || index} className="space-y-2" data-testid={`goal-item-${index}`}>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-foreground" data-testid={`text-goal-title-${index}`}>
                    {goal.title}
                  </span>
                  <span className="text-sm text-muted-foreground" data-testid={`text-goal-progress-${index}`}>
                    {goal.currentValue}/{goal.targetValue} {goal.unit}
                  </span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div 
                    className={`${progressColor} h-2 rounded-full transition-all duration-300`}
                    style={{ width: `${Math.min(progress, 100)}%` }}
                  />
                </div>
                <p className="text-xs text-muted-foreground" data-testid={`text-goal-description-${index}`}>
                  {goal.description}
                </p>
              </div>
            );
          })}
        </div>
        
        <AddGoalDialog />
      </CardContent>
    </Card>
  );
}
