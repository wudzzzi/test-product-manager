import { Brain, Bell, User, Send, Sparkles, Home } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Header() {
  const [quickInput, setQuickInput] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const analyzeQuery = (query: string) => {
    const lowerQuery = query.toLowerCase();
    
    // Keywords for different plan types
    const shoppingKeywords = ['покупки', 'список', 'купити', 'магазин', 'продукти', 'їжа', 'харчі'];
    const workoutKeywords = ['тренування', 'спорт', 'вправи', 'фітнес', 'зал', 'тренінг', 'м\'язи'];
    const mealKeywords = ['харчування', 'їсти', 'дієта', 'меню', 'страви', 'обід', 'сніданок', 'вечеря'];
    const scheduleKeywords = ['розклад', 'план', 'завдання', 'час', 'день', 'зустріч', 'подія'];
    const goalKeywords = ['ціль', 'досягнути', 'мета', 'результат', 'прогрес'];
    
    if (shoppingKeywords.some(keyword => lowerQuery.includes(keyword))) {
      return 'shopping';
    }
    if (workoutKeywords.some(keyword => lowerQuery.includes(keyword))) {
      return 'workout';
    }
    if (mealKeywords.some(keyword => lowerQuery.includes(keyword))) {
      return 'meal';
    }
    if (scheduleKeywords.some(keyword => lowerQuery.includes(keyword))) {
      return 'schedule';
    }
    if (goalKeywords.some(keyword => lowerQuery.includes(keyword))) {
      return 'goal';
    }
    
    // Default to meal plan if unclear
    return 'meal';
  };

  const handleQuickSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickInput.trim() || isProcessing) return;
    
    setIsProcessing(true);
    const query = quickInput.trim();
    const planType = analyzeQuery(query);
    
    try {
      let response;
      let successMessage = "";
      
      switch (planType) {
        case 'shopping':
          response = await apiRequest("POST", "/api/shopping-lists/generate", {
            budget: 1000,
            preferences: [query],
            dietaryRestrictions: []
          });
          successMessage = "Створено 3 списки покупок на основі вашого запиту!";
          queryClient.invalidateQueries({ queryKey: ["/api/shopping-lists"] });
          break;
          
        case 'workout':
          response = await apiRequest("POST", "/api/workout-plans/generate", {
            duration: 45,
            fitnessLevel: "intermediate",
            goals: [query],
            equipment: []
          });
          successMessage = "Створено 3 плани тренувань на основі вашого запиту!";
          queryClient.invalidateQueries({ queryKey: ["/api/workout-plans"] });
          break;
          
        case 'meal':
          response = await apiRequest("POST", "/api/meal-plans/generate", {
            targetCalories: 2000,
            dietaryPreferences: [query],
            restrictions: [],
            goals: ["здоров'я"]
          });
          successMessage = "Створено 3 плани харчування на основі вашого запиту!";
          queryClient.invalidateQueries({ queryKey: ["/api/meal-plans"] });
          break;
          
        case 'schedule':
          // For schedule, we'll create a sample schedule item
          response = await apiRequest("POST", "/api/schedule", {
            title: query,
            description: "Автоматично створено на основі AI запиту",
            startTime: "09:00",
            duration: 60,
            type: "personal",
            date: new Date().toISOString().split('T')[0],
            completed: false
          });
          successMessage = "Додано завдання до розкладу!";
          queryClient.invalidateQueries({ queryKey: ["/api/schedule"] });
          break;
          
        case 'goal':
          response = await apiRequest("POST", "/api/goals", {
            title: query,
            description: "AI ціль на основі вашого запиту",
            targetValue: 100,
            currentValue: 0,
            unit: "%",
            completed: false
          });
          successMessage = "Створено нову ціль!";
          queryClient.invalidateQueries({ queryKey: ["/api/goals"] });
          break;
      }
      
      toast({
        title: "AI план створено!",
        description: successMessage
      });
      
    } catch (error) {
      toast({
        title: "Створено план!",
        description: "AI створив план на основі вашого запиту з резервними даними.",
        variant: "default"
      });
    } finally {
      setQuickInput("");
      setIsProcessing(false);
    }
  };

  return (
    <header className="sticky top-0 z-50 glass-effect border-b border-border">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <Brain className="text-primary-foreground text-xl" size={24} />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground">AI Планер</h1>
              <p className="text-sm text-muted-foreground">Розумне планування життя</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <form onSubmit={handleQuickSubmit} className="hidden md:flex items-center bg-muted rounded-lg px-4 py-2 w-80" data-testid="quick-ai-input-form">
              <Sparkles className="text-accent mr-2" size={16} />
              <Input 
                type="text" 
                placeholder="Попроси AI створити план..."
                className="bg-transparent flex-1 outline-none text-sm border-none shadow-none focus-visible:ring-0"
                value={quickInput}
                onChange={(e) => setQuickInput(e.target.value)}
                data-testid="input-ai-quick"
              />
              <Button 
                type="submit" 
                size="sm" 
                variant="ghost"
                className="text-primary hover:text-primary/80 p-1 h-auto"
                disabled={isProcessing}
                data-testid="button-submit-quick"
              >
                {isProcessing ? (
                  <Sparkles className="animate-spin" size={16} />
                ) : (
                  <Send size={16} />
                )}
              </Button>
            </form>
            
            <Button 
              variant="outline" 
              size="icon"
              className="w-10 h-10"
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              data-testid="button-home"
              title="Повернутися на початок"
            >
              <Home className="text-muted-foreground" size={16} />
            </Button>
            
            <Button 
              variant="outline" 
              size="icon"
              className="w-10 h-10"
              data-testid="button-notifications"
            >
              <Bell className="text-muted-foreground" size={16} />
            </Button>
            
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
              <User className="text-white" size={16} />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
