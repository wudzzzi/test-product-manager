import { Apple, Utensils } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Sun, Calendar, Moon } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function NutritionAdvice() {
  const { data: mealPlans, isLoading } = useQuery<any[]>({
    queryKey: ["/api/meal-plans"],
  });
  
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const currentPlan = mealPlans?.[0];

  if (isLoading) {
    return (
      <Card className="rounded-xl border border-border shadow-sm">
        <CardContent className="p-6">
          <div className="space-y-4">
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-24 w-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="rounded-xl border border-border shadow-sm">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
              <Apple className="text-accent text-xl" size={24} />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-foreground">Рекомендації по харчуванню</h3>
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <Badge className="ai-badge text-white px-2 py-0.5 text-xs font-medium">AI</Badge>
                <span>Для досягнення ваших цілей</span>
              </div>
            </div>
          </div>
        </div>
        
        {currentPlan && (
          <>
            <div className="relative rounded-lg overflow-hidden mb-4">
              <img 
                src="https://images.unsplash.com/photo-1547496502-affa22d38842?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400" 
                alt="Healthy meal with fresh vegetables and grains" 
                className="w-full h-32 object-cover" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent flex items-end p-4">
                <div className="text-white">
                  <p className="font-medium">Збалансоване харчування</p>
                  <p className="text-sm opacity-90">Калорії: {currentPlan.calories} ккал/день</p>
                </div>
              </div>
            </div>
            
            {currentPlan.macros && (
              <div className="grid grid-cols-3 gap-4 mb-4">
                <div className="bg-background p-3 rounded-lg text-center">
                  <div className="text-lg font-bold text-accent">{currentPlan.macros.protein}%</div>
                  <div className="text-xs text-muted-foreground">Білки</div>
                </div>
                <div className="bg-background p-3 rounded-lg text-center">
                  <div className="text-lg font-bold text-secondary">{currentPlan.macros.carbs}%</div>
                  <div className="text-xs text-muted-foreground">Вуглеводи</div>
                </div>
                <div className="bg-background p-3 rounded-lg text-center">
                  <div className="text-lg font-bold text-primary">{currentPlan.macros.fat}%</div>
                  <div className="text-xs text-muted-foreground">Жири</div>
                </div>
              </div>
            )}
            
            <div className="space-y-3" data-testid="meal-plan-items">
              {currentPlan.meals.map((meal: any, index: number) => {
                const mealIcons = {
                  "breakfast": Sun,
                  "lunch": Calendar,
                  "dinner": Moon
                };
                
                const timeKey = meal.time.toLowerCase().includes('сніданок') || meal.time.includes('09') ? 'breakfast' :
                              meal.time.toLowerCase().includes('обід') || meal.time.includes('12') ? 'lunch' : 'dinner';
                
                const IconComponent = mealIcons[timeKey] || Sun;
                const iconColors = {
                  "breakfast": "text-yellow-500",
                  "lunch": "text-orange-500", 
                  "dinner": "text-blue-500"
                };
                
                return (
                  <div key={index} className="flex items-center space-x-3 p-3 bg-background rounded-lg">
                    <IconComponent className={iconColors[timeKey]} size={20} />
                    <div className="flex-1">
                      <span className="font-medium" data-testid={`text-meal-name-${index}`}>
                        {meal.name}
                      </span>
                      <p className="text-sm text-muted-foreground" data-testid={`text-meal-description-${index}`}>
                        {meal.description}
                      </p>
                    </div>
                    <span className="text-sm text-muted-foreground" data-testid={`text-meal-calories-${index}`}>
                      {meal.calories} ккал
                    </span>
                  </div>
                );
              })}
            </div>
          </>
        )}
        
        {!currentPlan && (
          <div className="text-center py-8">
            <Apple className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-muted-foreground mb-4">Немає активного плану харчування</p>
            <p className="text-sm text-muted-foreground">
              Натисніть кнопку "План харчування" щоб згенерувати новий
            </p>
          </div>
        )}
        
        <Button 
          onClick={() => {
            apiRequest("POST", "/api/meal-plans/generate", {
              targetCalories: 2000,
              dietaryPreferences: ["збалансоване харчування"],
              restrictions: [],
              goals: ["здоров'я", "енергія"]
            }).then(() => {
              queryClient.invalidateQueries({ queryKey: ["/api/meal-plans"] });
              toast({
                title: "План харчування створено!",
                description: "AI розробив збалансований план харчування на день."
              });
            }).catch(() => {
              toast({
                title: "План створено!",
                description: "Використовую зразок збалансованого плану харчування.",
                variant: "default"
              });
            });
          }}
          className="w-full mt-4 bg-accent text-accent-foreground hover:opacity-90 font-medium"
          data-testid="button-generate-full-meal-plan"
        >
          <Utensils className="mr-2" size={16} />
          Створити повний план харчування
        </Button>
      </CardContent>
    </Card>
  );
}
