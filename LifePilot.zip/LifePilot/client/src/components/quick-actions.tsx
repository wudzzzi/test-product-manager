import { ShoppingCart, Dumbbell, Utensils, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function QuickActions() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const generateShoppingListMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/shopping-lists/generate", {
      budget: 1200,
      preferences: ["здорова їжа", "свіжі продукти"],
      dietaryRestrictions: []
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/shopping-lists"] });
      toast({
        title: "Список покупок створено!",
        description: "AI згенерував персоналізований список покупок."
      });
    },
    onError: () => {
      toast({
        title: "Помилка",
        description: "Не вдалося створити список покупок.",
        variant: "destructive"
      });
    }
  });

  const generateWorkoutMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/workout-plans/generate", {
      duration: 45,
      fitnessLevel: "beginner",
      goals: ["схуднення", "підтримка форми"],
      equipment: []
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workout-plans"] });
      toast({
        title: "План тренувань готовий!",
        description: "AI створив персональний план тренувань."
      });
    },
    onError: () => {
      toast({
        title: "Помилка",
        description: "Не вдалося створити план тренувань.",
        variant: "destructive"
      });
    }
  });

  const generateMealPlanMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/meal-plans/generate", {
      targetCalories: 1800,
      dietaryPreferences: ["збалансоване харчування"],
      restrictions: [],
      goals: ["здоров'я"]
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/meal-plans"] });
      toast({
        title: "План харчування створено!",
        description: "AI розробив збалансований план харчування."
      });
    },
    onError: () => {
      toast({
        title: "Помилка",
        description: "Не вдалося створити план харчування.",
        variant: "destructive"
      });
    }
  });

  const optimizeScheduleMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/schedule/optimize", {
      currentSchedule: [],
      preferences: ["ранкові тренування", "здоровий сон"]
    }),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/schedule"] });
      toast({
        title: "Розклад оптимізовано!",
        description: "AI запропонував покращення для вашого розкладу."
      });
    },
    onError: () => {
      toast({
        title: "Помилка",
        description: "Не вдалося оптимізувати розклад.",
        variant: "destructive"
      });
    }
  });

  return (
    <div className="mb-8">
      <div className="flex flex-wrap gap-3">
        <Button 
          onClick={() => generateShoppingListMutation.mutate()}
          disabled={generateShoppingListMutation.isPending}
          className="flex items-center space-x-2 bg-primary text-primary-foreground hover:opacity-90 shadow-sm"
          data-testid="button-generate-shopping"
        >
          <ShoppingCart size={16} />
          <span className="font-medium">
            {generateShoppingListMutation.isPending ? "Створюю..." : "Створити список покупок"}
          </span>
        </Button>
        
        <Button 
          onClick={() => generateWorkoutMutation.mutate()}
          disabled={generateWorkoutMutation.isPending}
          className="flex items-center space-x-2 bg-secondary text-secondary-foreground hover:opacity-90 shadow-sm"
          data-testid="button-generate-workout"
        >
          <Dumbbell size={16} />
          <span className="font-medium">
            {generateWorkoutMutation.isPending ? "Створюю..." : "План тренувань"}
          </span>
        </Button>
        
        <Button 
          onClick={() => generateMealPlanMutation.mutate()}
          disabled={generateMealPlanMutation.isPending}
          className="flex items-center space-x-2 bg-accent text-accent-foreground hover:opacity-90 shadow-sm"
          data-testid="button-generate-meal"
        >
          <Utensils size={16} />
          <span className="font-medium">
            {generateMealPlanMutation.isPending ? "Створюю..." : "План харчування"}
          </span>
        </Button>
        
        <Button 
          onClick={() => optimizeScheduleMutation.mutate()}
          disabled={optimizeScheduleMutation.isPending}
          variant="outline"
          className="flex items-center space-x-2 hover:bg-muted shadow-sm"
          data-testid="button-optimize-schedule"
        >
          <Calendar size={16} />
          <span className="font-medium">
            {optimizeScheduleMutation.isPending ? "Оптимізую..." : "Оптимізувати розклад"}
          </span>
        </Button>
      </div>
    </div>
  );
}
