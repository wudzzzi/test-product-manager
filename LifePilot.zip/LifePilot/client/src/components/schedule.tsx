import { Calendar, Sparkles } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Dumbbell, Utensils, ShoppingCart } from "lucide-react";
import AddScheduleItemDialog from "@/components/add-schedule-item-dialog";

export default function Schedule() {
  const today = new Date().toISOString().split('T')[0];
  
  const { data: scheduleItems, isLoading } = useQuery<any[]>({
    queryKey: ["/api/schedule"],
  });

  if (isLoading) {
    return (
      <Card className="rounded-xl border border-border shadow-sm">
        <CardContent className="p-6">
          <div className="space-y-4">
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  const typeIcons = {
    workout: Dumbbell,
    meal: Utensils,
    shopping: ShoppingCart,
    default: Calendar
  };

  const typeColors = {
    workout: "text-secondary",
    meal: "text-accent", 
    shopping: "text-primary",
    default: "text-muted-foreground"
  };

  const typeBorders = {
    workout: "border-secondary",
    meal: "border-accent",
    shopping: "border-primary", 
    default: "border-muted"
  };

  const typeBackgrounds = {
    workout: "bg-secondary/10",
    meal: "bg-accent/10",
    shopping: "bg-primary/10",
    default: "bg-muted"
  };

  // Mock schedule data if no items
  const mockSchedule = [
    {
      id: "1",
      title: "Ранкова зарядка",
      description: "Персональний план тренувань",
      startTime: "09:00",
      duration: 30,
      type: "workout"
    },
    {
      id: "2", 
      title: "Обід",
      description: "Згідно плану харчування",
      startTime: "12:30",
      duration: 45,
      type: "meal"
    },
    {
      id: "3",
      title: "Покупки", 
      description: "Список AI планера",
      startTime: "15:00",
      duration: 60,
      type: "shopping"
    },
    {
      id: "4",
      title: "Силове тренування",
      description: "Спортзал",
      startTime: "19:00", 
      duration: 60,
      type: "workout"
    }
  ];

  const displayItems = scheduleItems?.length ? scheduleItems : mockSchedule;

  return (
    <Card className="rounded-xl border border-border shadow-sm">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">Сьогоднішній розклад</h3>
          <Button 
            variant="ghost" 
            size="icon"
            className="text-primary hover:text-primary/80"
            data-testid="button-optimize-schedule-sidebar"
          >
            <Sparkles size={16} />
          </Button>
        </div>
        
        <div className="space-y-3" data-testid="schedule-items">
          {displayItems.map((item: any, index: number) => {
            const IconComponent = typeIcons[item.type as keyof typeof typeIcons] || typeIcons.default;
            const iconColor = typeColors[item.type as keyof typeof typeColors] || typeColors.default;
            const borderColor = typeBorders[item.type as keyof typeof typeBorders] || typeBorders.default;
            const backgroundColor = typeBackgrounds[item.type as keyof typeof typeBackgrounds] || typeBackgrounds.default;
            
            return (
              <div 
                key={item.id || index} 
                className={`flex items-center space-x-3 p-3 ${backgroundColor} rounded-lg border-l-4 ${borderColor}`}
                data-testid={`schedule-item-${index}`}
              >
                <div className="text-center min-w-[50px]">
                  <div className="text-sm font-medium text-foreground" data-testid={`text-schedule-time-${index}`}>
                    {item.startTime}
                  </div>
                  <div className="text-xs text-muted-foreground" data-testid={`text-schedule-duration-${index}`}>
                    {item.duration}хв
                  </div>
                </div>
                <div className="flex-1">
                  <div className="font-medium text-foreground" data-testid={`text-schedule-title-${index}`}>
                    {item.title}
                  </div>
                  <div className="text-sm text-muted-foreground" data-testid={`text-schedule-description-${index}`}>
                    {item.description}
                  </div>
                </div>
                <IconComponent className={iconColor} size={20} />
              </div>
            );
          })}
        </div>
        
        <AddScheduleItemDialog />
      </CardContent>
    </Card>
  );
}
