import { ShoppingCart, MoreVertical } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import AddShoppingItemDialog from "@/components/add-shopping-item-dialog";

export default function ShoppingList() {
  const { data: shoppingLists, isLoading } = useQuery<any[]>({
    queryKey: ["/api/shopping-lists"],
  });

  const currentList = shoppingLists?.[0];

  if (isLoading) {
    return (
      <Card className="rounded-xl border border-border shadow-sm">
        <CardContent className="p-6">
          <div className="space-y-4">
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-32 w-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  const budgetUsed = currentList ? Math.round((currentList.totalCost / currentList.budget) * 100) : 0;

  return (
    <Card className="rounded-xl border border-border shadow-sm">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
              <ShoppingCart className="text-primary text-xl" size={24} />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-foreground">Розумний список покупок</h3>
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <Badge className="ai-badge text-white px-2 py-0.5 text-xs font-medium">AI</Badge>
                <span>Автоматично згенеровано з урахуванням бюджету</span>
              </div>
            </div>
          </div>
          <Button variant="ghost" size="icon" data-testid="button-shopping-options">
            <MoreVertical size={16} />
          </Button>
        </div>
        
        {currentList && (
          <>
            <div className="bg-muted rounded-lg p-4 mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-foreground">Бюджет на тиждень</span>
                <span className="text-lg font-bold text-secondary">₴{currentList.budget}</span>
              </div>
              <Progress value={budgetUsed} className="mb-1" />
              <p className="text-xs text-muted-foreground">
                Витрачено ₴{currentList.totalCost} з ₴{currentList.budget}
              </p>
            </div>
            
            <div className="space-y-3" data-testid="shopping-list-items">
              {currentList.items.map((item: any, index: number) => (
                <div key={index} className="flex items-center space-x-3 p-3 bg-background rounded-lg">
                  <Checkbox data-testid={`checkbox-item-${index}`} />
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className="font-medium" data-testid={`text-item-name-${index}`}>
                        {item.name} {item.quantity}
                      </span>
                      <span className="text-sm text-muted-foreground" data-testid={`text-item-price-${index}`}>
                        ₴{item.estimatedPrice}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground" data-testid={`text-item-store-${index}`}>
                      {item.store} {item.category && `- ${item.category}`}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
        
        {!currentList && (
          <div className="text-center py-8">
            <ShoppingCart className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-muted-foreground mb-4">Немає активних списків покупок</p>
            <p className="text-sm text-muted-foreground">
              Натисніть кнопку "Створити список покупок" щоб згенерувати новий
            </p>
          </div>
        )}
        
        <AddShoppingItemDialog />
      </CardContent>
    </Card>
  );
}
