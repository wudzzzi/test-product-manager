import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Lightbulb, Clock, Moon, Check } from "lucide-react";

export default function SmartReminders() {
  const { data: reminders, isLoading } = useQuery<any[]>({
    queryKey: ["/api/reminders"],
  });

  if (isLoading) {
    return (
      <Card className="rounded-xl border border-border shadow-sm">
        <CardContent className="p-6">
          <div className="space-y-4">
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  // Mock reminders data if no reminders exist
  const mockReminders = [
    {
      id: "1",
      title: "Час попити води!",
      message: "Ви не пили воду останні 2 години",
      type: "health",
      priority: "medium",
      icon: "lightbulb",
      backgroundColor: "bg-yellow-50 dark:bg-yellow-900/20",
      borderColor: "border-yellow-200 dark:border-yellow-800",
      iconColor: "text-yellow-600 dark:text-yellow-400",
      buttonColor: "text-yellow-600 hover:text-yellow-700 dark:text-yellow-400 dark:hover:text-yellow-300"
    },
    {
      id: "2",
      title: "Покупки о 15:00",
      message: "Не забудьте взяти еко-сумку",
      type: "schedule",
      priority: "high",
      icon: "clock",
      backgroundColor: "bg-blue-50 dark:bg-blue-900/20",
      borderColor: "border-blue-200 dark:border-blue-800",
      iconColor: "text-blue-600 dark:text-blue-400",
      buttonColor: "text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
    },
    {
      id: "3",
      title: "Час відпочинку",
      message: "Рекомендований сон о 22:30",
      type: "wellness",
      priority: "low",
      icon: "moon",
      backgroundColor: "bg-green-50 dark:bg-green-900/20",
      borderColor: "border-green-200 dark:border-green-800",
      iconColor: "text-green-600 dark:text-green-400",
      buttonColor: "text-green-600 hover:text-green-700 dark:text-green-400 dark:hover:text-green-300"
    }
  ];

  const displayReminders = reminders?.length ? reminders : mockReminders;

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "lightbulb": return Lightbulb;
      case "clock": return Clock;
      case "moon": return Moon;
      default: return Lightbulb;
    }
  };

  return (
    <Card className="rounded-xl border border-border shadow-sm">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">Розумні нагадування</h3>
          <div className="flex items-center space-x-1">
            <Badge className="ai-badge text-white px-2 py-0.5 text-xs font-medium">AI</Badge>
          </div>
        </div>
        
        <div className="space-y-3" data-testid="reminders-list">
          {displayReminders.map((reminder: any, index: number) => {
            const IconComponent = getIcon(reminder.icon || "lightbulb");
            
            return (
              <div 
                key={reminder.id || index} 
                className={`flex items-start space-x-3 p-3 ${reminder.backgroundColor} border ${reminder.borderColor} rounded-lg`}
                data-testid={`reminder-item-${index}`}
              >
                <IconComponent className={`${reminder.iconColor} mt-0.5`} size={16} />
                <div className="flex-1">
                  <p className="text-sm font-medium text-foreground" data-testid={`text-reminder-title-${index}`}>
                    {reminder.title}
                  </p>
                  <p className="text-xs text-muted-foreground" data-testid={`text-reminder-message-${index}`}>
                    {reminder.message}
                  </p>
                </div>
                <Button 
                  variant="ghost"
                  size="sm"
                  className={`${reminder.buttonColor} text-sm p-1 h-auto`}
                  data-testid={`button-dismiss-reminder-${index}`}
                >
                  <Check size={16} />
                </Button>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
