import { Dumbbell, Play, Edit, Youtube } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";

export default function WorkoutPlan() {
  const { data: workoutPlans, isLoading } = useQuery<any[]>({
    queryKey: ["/api/workout-plans"],
  });

  const currentPlan = workoutPlans?.[0];

  if (isLoading) {
    return (
      <Card className="rounded-xl border border-border shadow-sm">
        <CardContent className="p-6">
          <div className="space-y-4">
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-24 w-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="rounded-xl border border-border shadow-sm">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center">
              <Dumbbell className="text-secondary text-xl" size={24} />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-foreground">План тренувань на сьогодні</h3>
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <Badge className="ai-badge text-white px-2 py-0.5 text-xs font-medium">AI</Badge>
                <span>Персоналізовано під ваші цілі</span>
              </div>
            </div>
          </div>
          {currentPlan && (
            <div className="text-right">
              <p className="text-sm text-muted-foreground">{currentPlan.duration} хвилин</p>
              <p className="text-xs text-secondary font-medium">{currentPlan.difficulty}</p>
            </div>
          )}
        </div>
        
        {currentPlan && (
          <>
            <div className="relative rounded-lg overflow-hidden mb-4">
              <img 
                src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400" 
                alt="Modern gym interior with exercise equipment" 
                className="w-full h-32 object-cover" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent flex items-end p-4">
                <div className="text-white">
                  <p className="font-medium">Кардіо + силові вправи</p>
                  <p className="text-sm opacity-90">Спалювання калорій: ~350 ккал</p>
                </div>
              </div>
            </div>
            
            <div className="space-y-3" data-testid="workout-exercises">
              {currentPlan.exercises.map((exercise: any, index: number) => (
                <div key={index} className="flex items-center space-x-3 p-3 bg-background rounded-lg">
                  <div className="w-8 h-8 bg-secondary/20 rounded-full flex items-center justify-center text-secondary font-bold text-sm">
                    {index + 1}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className="font-medium" data-testid={`text-exercise-name-${index}`}>
                        {exercise.name}
                      </span>
                      <div className="flex items-center space-x-2">
                        <span className="text-sm text-muted-foreground" data-testid={`text-exercise-reps-${index}`}>
                          {exercise.sets}×{exercise.reps}
                        </span>
                        <Button 
                          size="sm"
                          className="w-6 h-6 bg-red-500 hover:bg-red-600 rounded-full p-0"
                          data-testid={`button-youtube-${index}`}
                        >
                          <Youtube className="text-white text-xs" size={12} />
                        </Button>
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground" data-testid={`text-exercise-rest-${index}`}>
                      Відпочинок: {exercise.restTime}
                    </p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="flex space-x-3 mt-4">
              <Button 
                className="flex-1 bg-secondary text-secondary-foreground hover:opacity-90 font-medium"
                data-testid="button-start-workout"
              >
                <Play className="mr-2" size={16} />
                Почати тренування
              </Button>
              <Button 
                variant="outline"
                size="icon"
                data-testid="button-customize-workout"
              >
                <Edit size={16} />
              </Button>
            </div>
          </>
        )}
        
        {!currentPlan && (
          <div className="text-center py-8">
            <Dumbbell className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-muted-foreground mb-4">Немає активного плану тренувань</p>
            <p className="text-sm text-muted-foreground">
              Натисніть кнопку "План тренувань" щоб згенерувати новий
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
