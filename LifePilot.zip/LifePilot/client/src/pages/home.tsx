import Header from "@/components/header";
import QuickActions from "@/components/quick-actions";
import ShoppingList from "@/components/shopping-list";
import WorkoutPlan from "@/components/workout-plan";
import NutritionAdvice from "@/components/nutrition-advice";
import Schedule from "@/components/schedule";
import GoalsProgress from "@/components/goals-progress";
import SmartReminders from "@/components/smart-reminders";
import FloatingAIButton from "@/components/floating-ai-button";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      
      <div className="container mx-auto px-4 py-6 max-w-7xl">
        <QuickActions />
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <ShoppingList />
            <WorkoutPlan />
            <NutritionAdvice />
          </div>
          
          <div className="space-y-6">
            <Schedule />
            <GoalsProgress />
            <SmartReminders />
          </div>
        </div>
      </div>
      
      <FloatingAIButton />
    </div>
  );
}
