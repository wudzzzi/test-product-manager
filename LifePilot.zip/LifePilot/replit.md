# Overview

AI Планер (AI Planner) is a comprehensive life management application that uses artificial intelligence to help users organize their daily activities. The app provides AI-generated shopping lists, workout plans, meal plans, and smart scheduling with an intelligent reminder system. Built as a full-stack web application, it features a React frontend with TypeScript and a Node.js/Express backend, designed to simplify personal planning through automated, personalized recommendations.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript, using Vite as the build tool
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state management and caching
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **Component Structure**: Modular components organized by feature (shopping lists, workout plans, meal plans, schedule, goals, reminders)

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful endpoints organized by resource type
- **Middleware**: Custom logging middleware for API request tracking
- **Error Handling**: Centralized error handling with status codes and JSON responses

## Data Storage Solutions
- **Database**: PostgreSQL with Neon Database as the serverless provider
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema Management**: Shared schema definitions between client and server
- **Storage Interface**: Abstract storage layer with in-memory fallback implementation
- **Data Models**: Users, shopping lists, workout plans, meal plans, goals, schedule items, and reminders

## Authentication and Authorization
- **Current State**: Simplified with default user ID for demo purposes
- **Session Management**: Connect-pg-simple for PostgreSQL session storage
- **Future Extensibility**: User authentication system prepared in schema but not implemented

## External Service Integrations
- **OpenAI API**: GPT-5 model integration for generating personalized content (shopping lists, workout plans, meal plans, schedule optimization, smart reminders)
- **YouTube API**: Video search integration for workout tutorial recommendations
- **Fallback Strategy**: Graceful degradation with mock data when external APIs are unavailable

## Development and Deployment Architecture
- **Development**: Hot module replacement with Vite dev server
- **Build Process**: Vite for frontend bundling, esbuild for backend compilation
- **Environment**: Replit-optimized with runtime error overlay and development banner
- **Static Assets**: Served through Express with Vite middleware in development

## Key Design Patterns
- **Component Composition**: Extensive use of Radix UI primitives for accessibility
- **Type Safety**: End-to-end TypeScript with shared schema validation using Zod
- **Responsive Design**: Mobile-first approach with Tailwind breakpoints
- **Loading States**: Skeleton components for improved perceived performance
- **Error Boundaries**: Toast notifications for user feedback

# External Dependencies

## Core Framework Dependencies
- **React Ecosystem**: React 18, Vite, TanStack React Query for frontend
- **Backend**: Express.js, TypeScript, tsx for development runtime
- **Database**: PostgreSQL via Neon Database serverless platform
- **ORM**: Drizzle ORM with Drizzle Kit for migrations

## UI and Styling
- **Component Library**: Radix UI primitives for accessible components
- **Styling**: Tailwind CSS with PostCSS processing
- **Icons**: Lucide React for consistent iconography
- **Fonts**: Google Fonts integration (Inter, DM Sans, Fira Code, Geist Mono)

## External APIs
- **OpenAI API**: GPT-5 model for AI-generated content recommendations
- **YouTube Data API v3**: Workout video search and recommendation system
- **Configuration**: Environment variable based API key management

## Development Tools
- **Replit Integration**: Cartographer plugin, runtime error modal, development banner
- **Build Tools**: esbuild for backend compilation, Vite for frontend bundling
- **Validation**: Zod for runtime type checking and schema validation

## Database and Storage
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Session Storage**: connect-pg-simple for PostgreSQL-backed sessions
- **Migration Tool**: Drizzle Kit for database schema management