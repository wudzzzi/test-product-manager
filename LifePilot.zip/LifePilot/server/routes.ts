import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertShoppingListSchema,
  insertWorkoutPlanSchema,
  insertMealPlanSchema,
  insertGoalSchema,
  insertScheduleItemSchema,
  insertReminderSchema
} from "@shared/schema";
import { 
  generateShoppingList,
  generateWorkoutPlan,
  generateMealPlan,
  optimizeSchedule,
  generateSmartReminders
} from "./services/openai";
import { searchWorkoutVideos } from "./services/youtube";

export async function registerRoutes(app: Express): Promise<Server> {
  const DEFAULT_USER_ID = "default-user"; // Simplified for demo

  // Shopping Lists
  app.get("/api/shopping-lists", async (req, res) => {
    try {
      const lists = await storage.getShoppingLists(DEFAULT_USER_ID);
      res.json(lists);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch shopping lists" });
    }
  });

  app.post("/api/shopping-lists", async (req, res) => {
    try {
      const data = insertShoppingListSchema.parse({ ...req.body, userId: DEFAULT_USER_ID });
      const list = await storage.createShoppingList(data);
      res.json(list);
    } catch (error) {
      res.status(400).json({ message: "Invalid shopping list data" });
    }
  });

  app.post("/api/shopping-lists/generate", async (req, res) => {
    try {
      const { budget, preferences = [], dietaryRestrictions = [] } = req.body;
      
      // Generate 3 shopping lists
      const promises = [];
      for (let i = 0; i < 3; i++) {
        promises.push(generateShoppingList(budget, preferences, dietaryRestrictions));
      }
      
      const aiResults = await Promise.all(promises);
      
      const shoppingLists = [];
      for (let i = 0; i < aiResults.length; i++) {
        const aiResult = aiResults[i];
        const shoppingList = await storage.createShoppingList({
          userId: DEFAULT_USER_ID,
          name: `AI Generated Shopping List ${i + 1}`,
          budget: budget,
          totalCost: aiResult.totalEstimatedCost,
          items: aiResult.items
        });
        shoppingLists.push(shoppingList);
      }

      res.json({ created: shoppingLists.length, lists: shoppingLists });
    } catch (error) {
      res.status(500).json({ message: "Failed to generate shopping list: " + (error as Error).message });
    }
  });

  // Workout Plans
  app.get("/api/workout-plans", async (req, res) => {
    try {
      const plans = await storage.getWorkoutPlans(DEFAULT_USER_ID);
      res.json(plans);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch workout plans" });
    }
  });

  app.post("/api/workout-plans", async (req, res) => {
    try {
      const data = insertWorkoutPlanSchema.parse({ ...req.body, userId: DEFAULT_USER_ID });
      const plan = await storage.createWorkoutPlan(data);
      res.json(plan);
    } catch (error) {
      res.status(400).json({ message: "Invalid workout plan data" });
    }
  });

  app.post("/api/workout-plans/generate", async (req, res) => {
    try {
      const { duration = 30, fitnessLevel = "beginner", goals = [], equipment = [] } = req.body;
      
      // Generate 3 workout plans
      const promises = [];
      for (let i = 0; i < 3; i++) {
        promises.push(generateWorkoutPlan(duration, fitnessLevel, goals, equipment));
      }
      
      const aiResults = await Promise.all(promises);
      
      const workoutPlans = [];
      for (let i = 0; i < aiResults.length; i++) {
        const aiResult = aiResults[i];
        const workoutPlan = await storage.createWorkoutPlan({
          userId: DEFAULT_USER_ID,
          name: `AI Generated Workout Plan ${i + 1}`,
          duration: aiResult.totalDuration,
          difficulty: aiResult.difficulty,
          exercises: aiResult.exercises
        });
        workoutPlans.push(workoutPlan);
      }

      res.json({ created: workoutPlans.length, plans: workoutPlans });
    } catch (error) {
      res.status(500).json({ message: "Failed to generate workout plan: " + (error as Error).message });
    }
  });

  // YouTube videos for exercises
  app.get("/api/workout-videos/:query", async (req, res) => {
    try {
      const { query } = req.params;
      const videos = await searchWorkoutVideos(query);
      res.json(videos);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch workout videos" });
    }
  });

  // Meal Plans
  app.get("/api/meal-plans", async (req, res) => {
    try {
      const plans = await storage.getMealPlans(DEFAULT_USER_ID);
      res.json(plans);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch meal plans" });
    }
  });

  app.post("/api/meal-plans", async (req, res) => {
    try {
      const data = insertMealPlanSchema.parse({ ...req.body, userId: DEFAULT_USER_ID });
      const plan = await storage.createMealPlan(data);
      res.json(plan);
    } catch (error) {
      res.status(400).json({ message: "Invalid meal plan data" });
    }
  });

  app.post("/api/meal-plans/generate", async (req, res) => {
    try {
      const { 
        targetCalories = 2000, 
        dietaryPreferences = [], 
        restrictions = [], 
        goals = [] 
      } = req.body;
      
      // Generate 3 meal plans
      const promises = [];
      for (let i = 0; i < 3; i++) {
        promises.push(generateMealPlan(targetCalories, dietaryPreferences, restrictions, goals));
      }
      
      const aiResults = await Promise.all(promises);
      
      const mealPlans = [];
      for (let i = 0; i < aiResults.length; i++) {
        const aiResult = aiResults[i];
        const mealPlan = await storage.createMealPlan({
          userId: DEFAULT_USER_ID,
          name: `AI Generated Meal Plan ${i + 1}`,
          calories: aiResult.totalCalories,
          macros: aiResult.macros,
          meals: aiResult.meals
        });
        mealPlans.push(mealPlan);
      }

      res.json({ created: mealPlans.length, plans: mealPlans });
    } catch (error) {
      res.status(500).json({ message: "Failed to generate meal plan: " + (error as Error).message });
    }
  });

  // Goals
  app.get("/api/goals", async (req, res) => {
    try {
      const goals = await storage.getGoals(DEFAULT_USER_ID);
      res.json(goals);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch goals" });
    }
  });

  app.post("/api/goals", async (req, res) => {
    try {
      const data = insertGoalSchema.parse({ ...req.body, userId: DEFAULT_USER_ID });
      const goal = await storage.createGoal(data);
      res.json(goal);
    } catch (error) {
      res.status(400).json({ message: "Invalid goal data" });
    }
  });

  app.patch("/api/goals/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const goal = await storage.updateGoal(id, req.body);
      if (!goal) {
        return res.status(404).json({ message: "Goal not found" });
      }
      res.json(goal);
    } catch (error) {
      res.status(500).json({ message: "Failed to update goal" });
    }
  });

  // Schedule Items
  app.get("/api/schedule", async (req, res) => {
    try {
      const { date } = req.query;
      const items = await storage.getScheduleItems(DEFAULT_USER_ID, date as string);
      res.json(items);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch schedule items" });
    }
  });

  app.post("/api/schedule", async (req, res) => {
    try {
      const data = insertScheduleItemSchema.parse({ ...req.body, userId: DEFAULT_USER_ID });
      const item = await storage.createScheduleItem(data);
      res.json(item);
    } catch (error) {
      res.status(400).json({ message: "Invalid schedule item data" });
    }
  });

  app.post("/api/schedule/optimize", async (req, res) => {
    try {
      const { currentSchedule, preferences = [] } = req.body;
      
      const aiResult = await optimizeSchedule(currentSchedule, preferences);
      res.json(aiResult);
    } catch (error) {
      res.status(500).json({ message: "Failed to optimize schedule: " + (error as Error).message });
    }
  });

  // Reminders
  app.get("/api/reminders", async (req, res) => {
    try {
      const reminders = await storage.getReminders(DEFAULT_USER_ID);
      res.json(reminders);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch reminders" });
    }
  });

  app.post("/api/reminders", async (req, res) => {
    try {
      const data = insertReminderSchema.parse({ ...req.body, userId: DEFAULT_USER_ID });
      const reminder = await storage.createReminder(data);
      res.json(reminder);
    } catch (error) {
      res.status(400).json({ message: "Invalid reminder data" });
    }
  });

  app.post("/api/reminders/generate", async (req, res) => {
    try {
      const { userActivities = [], goals = [], preferences = [] } = req.body;
      
      const aiResult = await generateSmartReminders(userActivities, goals, preferences);
      
      // Create reminders in storage
      const createdReminders = await Promise.all(
        aiResult.reminders.map(reminder => 
          storage.createReminder({
            userId: DEFAULT_USER_ID,
            title: reminder.title,
            message: reminder.message,
            type: reminder.type,
            priority: reminder.priority
          })
        )
      );

      res.json(createdReminders);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate smart reminders: " + (error as Error).message });
    }
  });

  app.patch("/api/reminders/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const reminder = await storage.updateReminder(id, req.body);
      if (!reminder) {
        return res.status(404).json({ message: "Reminder not found" });
      }
      res.json(reminder);
    } catch (error) {
      res.status(500).json({ message: "Failed to update reminder" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
