import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key" 
});

interface ShoppingListItem {
  name: string;
  quantity: string;
  estimatedPrice: number;
  store: string;
  category: string;
}

interface WorkoutExercise {
  name: string;
  sets: number;
  reps: string;
  restTime: string;
  description: string;
  youtubeQuery: string;
}

interface Meal {
  name: string;
  time: string;
  calories: number;
  description: string;
  ingredients: string[];
}

export async function generateShoppingList(
  budget: number,
  preferences: string[] = [],
  dietaryRestrictions: string[] = []
): Promise<{ items: ShoppingListItem[], totalEstimatedCost: number }> {
  try {
    const prompt = `Generate a smart shopping list for a weekly grocery budget of ${budget} UAH. 
    Consider these preferences: ${preferences.join(', ')} and dietary restrictions: ${dietaryRestrictions.join(', ')}.
    
    Provide realistic Ukrainian grocery prices and suggest the best stores for each item.
    Include variety of healthy foods across all categories.
    
    Respond with JSON in this format:
    {
      "items": [
        {
          "name": "item name",
          "quantity": "amount with unit",
          "estimatedPrice": price_in_uah,
          "store": "store name",
          "category": "food category"
        }
      ],
      "totalEstimatedCost": total_cost
    }`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are a smart shopping assistant that helps create budget-friendly grocery lists with realistic Ukrainian prices."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    return result;
  } catch (error) {
    // Fallback data when API quota is exceeded or other errors occur
    console.log('OpenAI API error, using fallback data:', error);
    return {
      items: [
        { name: "Хліб цільнозерновий", quantity: "1 буханка", estimatedPrice: 35, store: "АТБ", category: "хлібобулочні" },
        { name: "Молоко 2.5%", quantity: "1 л", estimatedPrice: 42, store: "Сільпо", category: "молочні" },
        { name: "Яйця курячі", quantity: "10 шт", estimatedPrice: 55, store: "Новус", category: "молочні" },
        { name: "Куряче філе", quantity: "1 кг", estimatedPrice: 180, store: "Метро", category: "м'ясо" },
        { name: "Рис довгозернистий", quantity: "1 кг", estimatedPrice: 48, store: "АТБ", category: "крупи" },
        { name: "Банани", quantity: "1 кг", estimatedPrice: 35, store: "Сільпо", category: "фрукти" },
        { name: "Яблука", quantity: "1 кг", estimatedPrice: 25, store: "АТБ", category: "фрукти" },
        { name: "Морква", quantity: "1 кг", estimatedPrice: 18, store: "АТБ", category: "овочі" },
        { name: "Цибуля", quantity: "1 кг", estimatedPrice: 15, store: "АТБ", category: "овочі" },
        { name: "Картопля", quantity: "2 кг", estimatedPrice: 30, store: "АТБ", category: "овочі" },
        { name: "Гречка", quantity: "1 кг", estimatedPrice: 45, store: "Сільпо", category: "крупи" },
        { name: "Олія соняшникова", quantity: "1 л", estimatedPrice: 65, store: "Новус", category: "олії" }
      ],
      totalEstimatedCost: Math.min(budget - 50, 693)
    };
  }
}

export async function generateWorkoutPlan(
  duration: number,
  fitnessLevel: string = "beginner",
  goals: string[] = [],
  equipment: string[] = []
): Promise<{ exercises: WorkoutExercise[], totalDuration: number, difficulty: string }> {
  try {
    const prompt = `Create a ${duration}-minute workout plan for a ${fitnessLevel} level person.
    Goals: ${goals.join(', ')}
    Available equipment: ${equipment.length ? equipment.join(', ') : 'bodyweight only'}
    
    Include proper rest times and exercise descriptions.
    For each exercise, provide a YouTube search query that would find good tutorial videos.
    
    Respond with JSON in this format:
    {
      "exercises": [
        {
          "name": "exercise name",
          "sets": number,
          "reps": "reps or duration",
          "restTime": "rest time",
          "description": "how to perform",
          "youtubeQuery": "search query for YouTube"
        }
      ],
      "totalDuration": ${duration},
      "difficulty": "difficulty level"
    }`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are a certified fitness trainer that creates personalized workout plans."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    return result;
  } catch (error) {
    // Fallback data when API quota is exceeded
    console.log('OpenAI API error, using fallback data:', error);
    return {
      exercises: [
        { name: "Розминка", sets: 1, reps: "5 хв", restTime: "0 сек", description: "Легкі рухи для розігріву тіла", youtubeQuery: "warm up exercises" },
        { name: "Присідання", sets: 3, reps: "15-20", restTime: "60 сек", description: "Класичні присідання з власною вагою", youtubeQuery: "bodyweight squats tutorial" },
        { name: "Віджимання", sets: 3, reps: "10-15", restTime: "60 сек", description: "Віджимання від підлоги або з колін", youtubeQuery: "push ups beginner tutorial" },
        { name: "Планка", sets: 3, reps: "30-60 сек", restTime: "60 сек", description: "Утримання планки для зміцнення кору", youtubeQuery: "plank exercise tutorial" },
        { name: "Виступи", sets: 2, reps: "10 на ногу", restTime: "45 сек", description: "Виступи вперед для ніг та сідниць", youtubeQuery: "lunges exercise tutorial" },
        { name: "Розтяжка", sets: 1, reps: "5 хв", restTime: "0 сек", description: "Розтяжка всіх груп м'язів", youtubeQuery: "full body stretching routine" }
      ],
      totalDuration: duration,
      difficulty: fitnessLevel
    };
  }
}

export async function generateMealPlan(
  targetCalories: number,
  dietaryPreferences: string[] = [],
  restrictions: string[] = [],
  goals: string[] = []
): Promise<{ meals: Meal[], totalCalories: number, macros: { protein: number, carbs: number, fat: number } }> {
  try {
    const prompt = `Create a daily meal plan with approximately ${targetCalories} calories.
    Dietary preferences: ${dietaryPreferences.join(', ')}
    Restrictions: ${restrictions.join(', ')}
    Goals: ${goals.join(', ')}
    
    Include breakfast, lunch, dinner, and 1-2 snacks.
    Provide macro breakdown as percentages.
    Use ingredients commonly available in Ukraine.
    
    Respond with JSON in this format:
    {
      "meals": [
        {
          "name": "meal name",
          "time": "meal time",
          "calories": calories_number,
          "description": "meal description",
          "ingredients": ["ingredient1", "ingredient2"]
        }
      ],
      "totalCalories": total_calories,
      "macros": {
        "protein": percentage,
        "carbs": percentage, 
        "fat": percentage
      }
    }`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are a nutritionist that creates balanced meal plans based on individual needs and preferences."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    return result;
  } catch (error) {
    // Fallback data when API quota is exceeded
    console.log('OpenAI API error, using fallback data:', error);
    return {
      meals: [
        { name: "Вівсяна каша з фруктами", time: "08:00 - Сніданок", calories: 350, description: "Вівсяна каша на молоці з бананом та яблуком", ingredients: ["вівсяні пластівці", "молоко", "банан", "яблуко", "мед"] },
        { name: "Горіхи та йогурт", time: "11:00 - Перекус", calories: 180, description: "Натуральний йогурт з грецькими горіхами", ingredients: ["йогурт", "грецькі горіхи"] },
        { name: "Курка з рисом та овочами", time: "13:00 - Обід", calories: 550, description: "Запечена курка з бурим рисом та овочевим салатом", ingredients: ["куряче філе", "бурий рис", "броколі", "морква", "оливкова олія"] },
        { name: "Фруктовий салат", time: "16:00 - Перекус", calories: 120, description: "Свіжі фрукти з невеликою кількістю меду", ingredients: ["яблуко", "груша", "апельсин", "мед"] },
        { name: "Риба з овочами", time: "19:00 - Вечеря", calories: 400, description: "Запечена риба з тушкованими овочами", ingredients: ["лосось", "кабачок", "баклажан", "помідори", "часник", "зелень"] }
      ],
      totalCalories: 1600,
      macros: { protein: 25, carbs: 50, fat: 25 }
    };
  }
}

export async function optimizeSchedule(
  currentSchedule: any[],
  preferences: string[] = []
): Promise<{ optimizedSchedule: any[], suggestions: string[] }> {
  try {
    const prompt = `Optimize this daily schedule for better productivity and health:
    Current schedule: ${JSON.stringify(currentSchedule)}
    Preferences: ${preferences.join(', ')}
    
    Suggest improvements for better time management, health breaks, and efficiency.
    Consider optimal times for different activities.
    
    Respond with JSON in this format:
    {
      "optimizedSchedule": [
        {
          "time": "HH:MM",
          "activity": "activity name",
          "duration": minutes,
          "reason": "why this timing is optimal"
        }
      ],
      "suggestions": ["suggestion1", "suggestion2"]
    }`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are a productivity expert that helps optimize daily schedules for better work-life balance and health."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    return result;
  } catch (error) {
    throw new Error("Failed to optimize schedule: " + (error as Error).message);
  }
}

export async function generateSmartReminders(
  userActivities: any[],
  goals: any[] = [],
  preferences: string[] = []
): Promise<{ reminders: any[] }> {
  try {
    const prompt = `Generate smart reminders based on user activities and goals:
    Recent activities: ${JSON.stringify(userActivities)}
    Goals: ${JSON.stringify(goals)}
    Preferences: ${preferences.join(', ')}
    
    Create helpful, contextual reminders that support the user's goals and well-being.
    Include different types: health, productivity, goal progress, etc.
    
    Respond with JSON in this format:
    {
      "reminders": [
        {
          "title": "reminder title",
          "message": "detailed message",
          "type": "reminder type",
          "priority": "high|medium|low",
          "icon": "font-awesome icon class"
        }
      ]
    }`;

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are a smart assistant that creates helpful, contextual reminders to support user's goals and well-being."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    return result;
  } catch (error) {
    throw new Error("Failed to generate smart reminders: " + (error as Error).message);
  }
}
