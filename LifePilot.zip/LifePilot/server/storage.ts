import { 
  type User, 
  type InsertUser,
  type ShoppingList,
  type InsertShoppingList,
  type WorkoutPlan,
  type InsertWorkoutPlan,
  type MealPlan,
  type InsertMealPlan,
  type Goal,
  type InsertGoal,
  type ScheduleItem,
  type InsertScheduleItem,
  type Reminder,
  type InsertReminder
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Shopping Lists
  getShoppingLists(userId: string): Promise<ShoppingList[]>;
  getShoppingList(id: string): Promise<ShoppingList | undefined>;
  createShoppingList(shoppingList: InsertShoppingList): Promise<ShoppingList>;
  updateShoppingList(id: string, updates: Partial<ShoppingList>): Promise<ShoppingList | undefined>;
  deleteShoppingList(id: string): Promise<boolean>;

  // Workout Plans
  getWorkoutPlans(userId: string): Promise<WorkoutPlan[]>;
  getWorkoutPlan(id: string): Promise<WorkoutPlan | undefined>;
  createWorkoutPlan(workoutPlan: InsertWorkoutPlan): Promise<WorkoutPlan>;
  updateWorkoutPlan(id: string, updates: Partial<WorkoutPlan>): Promise<WorkoutPlan | undefined>;
  deleteWorkoutPlan(id: string): Promise<boolean>;

  // Meal Plans
  getMealPlans(userId: string): Promise<MealPlan[]>;
  getMealPlan(id: string): Promise<MealPlan | undefined>;
  createMealPlan(mealPlan: InsertMealPlan): Promise<MealPlan>;
  updateMealPlan(id: string, updates: Partial<MealPlan>): Promise<MealPlan | undefined>;
  deleteMealPlan(id: string): Promise<boolean>;

  // Goals
  getGoals(userId: string): Promise<Goal[]>;
  getGoal(id: string): Promise<Goal | undefined>;
  createGoal(goal: InsertGoal): Promise<Goal>;
  updateGoal(id: string, updates: Partial<Goal>): Promise<Goal | undefined>;
  deleteGoal(id: string): Promise<boolean>;

  // Schedule Items
  getScheduleItems(userId: string, date?: string): Promise<ScheduleItem[]>;
  getScheduleItem(id: string): Promise<ScheduleItem | undefined>;
  createScheduleItem(scheduleItem: InsertScheduleItem): Promise<ScheduleItem>;
  updateScheduleItem(id: string, updates: Partial<ScheduleItem>): Promise<ScheduleItem | undefined>;
  deleteScheduleItem(id: string): Promise<boolean>;

  // Reminders
  getReminders(userId: string): Promise<Reminder[]>;
  getReminder(id: string): Promise<Reminder | undefined>;
  createReminder(reminder: InsertReminder): Promise<Reminder>;
  updateReminder(id: string, updates: Partial<Reminder>): Promise<Reminder | undefined>;
  deleteReminder(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private shoppingLists: Map<string, ShoppingList>;
  private workoutPlans: Map<string, WorkoutPlan>;
  private mealPlans: Map<string, MealPlan>;
  private goals: Map<string, Goal>;
  private scheduleItems: Map<string, ScheduleItem>;
  private reminders: Map<string, Reminder>;

  constructor() {
    this.users = new Map();
    this.shoppingLists = new Map();
    this.workoutPlans = new Map();
    this.mealPlans = new Map();
    this.goals = new Map();
    this.scheduleItems = new Map();
    this.reminders = new Map();
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Shopping Lists
  async getShoppingLists(userId: string): Promise<ShoppingList[]> {
    return Array.from(this.shoppingLists.values()).filter(
      (list) => list.userId === userId
    );
  }

  async getShoppingList(id: string): Promise<ShoppingList | undefined> {
    return this.shoppingLists.get(id);
  }

  async createShoppingList(insertShoppingList: InsertShoppingList): Promise<ShoppingList> {
    const id = randomUUID();
    const shoppingList: ShoppingList = {
      ...insertShoppingList,
      id,
      budget: insertShoppingList.budget ?? null,
      totalCost: insertShoppingList.totalCost ?? 0,
      items: insertShoppingList.items ?? [],
      createdAt: new Date(),
    };
    this.shoppingLists.set(id, shoppingList);
    return shoppingList;
  }

  async updateShoppingList(id: string, updates: Partial<ShoppingList>): Promise<ShoppingList | undefined> {
    const existing = this.shoppingLists.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.shoppingLists.set(id, updated);
    return updated;
  }

  async deleteShoppingList(id: string): Promise<boolean> {
    return this.shoppingLists.delete(id);
  }

  // Workout Plans
  async getWorkoutPlans(userId: string): Promise<WorkoutPlan[]> {
    return Array.from(this.workoutPlans.values()).filter(
      (plan) => plan.userId === userId
    );
  }

  async getWorkoutPlan(id: string): Promise<WorkoutPlan | undefined> {
    return this.workoutPlans.get(id);
  }

  async createWorkoutPlan(insertWorkoutPlan: InsertWorkoutPlan): Promise<WorkoutPlan> {
    const id = randomUUID();
    const workoutPlan: WorkoutPlan = {
      ...insertWorkoutPlan,
      id,
      duration: insertWorkoutPlan.duration ?? null,
      difficulty: insertWorkoutPlan.difficulty ?? null,
      exercises: insertWorkoutPlan.exercises ?? [],
      createdAt: new Date(),
    };
    this.workoutPlans.set(id, workoutPlan);
    return workoutPlan;
  }

  async updateWorkoutPlan(id: string, updates: Partial<WorkoutPlan>): Promise<WorkoutPlan | undefined> {
    const existing = this.workoutPlans.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.workoutPlans.set(id, updated);
    return updated;
  }

  async deleteWorkoutPlan(id: string): Promise<boolean> {
    return this.workoutPlans.delete(id);
  }

  // Meal Plans
  async getMealPlans(userId: string): Promise<MealPlan[]> {
    return Array.from(this.mealPlans.values()).filter(
      (plan) => plan.userId === userId
    );
  }

  async getMealPlan(id: string): Promise<MealPlan | undefined> {
    return this.mealPlans.get(id);
  }

  async createMealPlan(insertMealPlan: InsertMealPlan): Promise<MealPlan> {
    const id = randomUUID();
    const mealPlan: MealPlan = {
      ...insertMealPlan,
      id,
      calories: insertMealPlan.calories ?? null,
      macros: insertMealPlan.macros ?? null,
      meals: insertMealPlan.meals ?? [],
      createdAt: new Date(),
    };
    this.mealPlans.set(id, mealPlan);
    return mealPlan;
  }

  async updateMealPlan(id: string, updates: Partial<MealPlan>): Promise<MealPlan | undefined> {
    const existing = this.mealPlans.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.mealPlans.set(id, updated);
    return updated;
  }

  async deleteMealPlan(id: string): Promise<boolean> {
    return this.mealPlans.delete(id);
  }

  // Goals
  async getGoals(userId: string): Promise<Goal[]> {
    return Array.from(this.goals.values()).filter(
      (goal) => goal.userId === userId
    );
  }

  async getGoal(id: string): Promise<Goal | undefined> {
    return this.goals.get(id);
  }

  async createGoal(insertGoal: InsertGoal): Promise<Goal> {
    const id = randomUUID();
    const goal: Goal = {
      ...insertGoal,
      id,
      description: insertGoal.description ?? null,
      targetValue: insertGoal.targetValue ?? null,
      currentValue: insertGoal.currentValue ?? 0,
      unit: insertGoal.unit ?? null,
      completed: insertGoal.completed ?? false,
      createdAt: new Date(),
    };
    this.goals.set(id, goal);
    return goal;
  }

  async updateGoal(id: string, updates: Partial<Goal>): Promise<Goal | undefined> {
    const existing = this.goals.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.goals.set(id, updated);
    return updated;
  }

  async deleteGoal(id: string): Promise<boolean> {
    return this.goals.delete(id);
  }

  // Schedule Items
  async getScheduleItems(userId: string, date?: string): Promise<ScheduleItem[]> {
    return Array.from(this.scheduleItems.values()).filter(
      (item) => item.userId === userId && (!date || item.date === date)
    );
  }

  async getScheduleItem(id: string): Promise<ScheduleItem | undefined> {
    return this.scheduleItems.get(id);
  }

  async createScheduleItem(insertScheduleItem: InsertScheduleItem): Promise<ScheduleItem> {
    const id = randomUUID();
    const scheduleItem: ScheduleItem = {
      ...insertScheduleItem,
      id,
      description: insertScheduleItem.description ?? null,
      duration: insertScheduleItem.duration ?? null,
      type: insertScheduleItem.type ?? null,
      completed: insertScheduleItem.completed ?? false,
    };
    this.scheduleItems.set(id, scheduleItem);
    return scheduleItem;
  }

  async updateScheduleItem(id: string, updates: Partial<ScheduleItem>): Promise<ScheduleItem | undefined> {
    const existing = this.scheduleItems.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.scheduleItems.set(id, updated);
    return updated;
  }

  async deleteScheduleItem(id: string): Promise<boolean> {
    return this.scheduleItems.delete(id);
  }

  // Reminders
  async getReminders(userId: string): Promise<Reminder[]> {
    return Array.from(this.reminders.values()).filter(
      (reminder) => reminder.userId === userId && !reminder.dismissed
    );
  }

  async getReminder(id: string): Promise<Reminder | undefined> {
    return this.reminders.get(id);
  }

  async createReminder(insertReminder: InsertReminder): Promise<Reminder> {
    const id = randomUUID();
    const reminder: Reminder = {
      ...insertReminder,
      id,
      message: insertReminder.message ?? null,
      type: insertReminder.type ?? null,
      priority: insertReminder.priority ?? null,
      dismissed: insertReminder.dismissed ?? false,
      createdAt: new Date(),
    };
    this.reminders.set(id, reminder);
    return reminder;
  }

  async updateReminder(id: string, updates: Partial<Reminder>): Promise<Reminder | undefined> {
    const existing = this.reminders.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.reminders.set(id, updated);
    return updated;
  }

  async deleteReminder(id: string): Promise<boolean> {
    return this.reminders.delete(id);
  }
}

export const storage = new MemStorage();
